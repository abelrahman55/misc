<?php echo $__env->make('dashboard.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<style>
    .price-offer {
        background: #fff;
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        padding: 20px;
        margin-bottom: 25px;
        transition: 0.3s;
    }

    .price-offer:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 15px rgba(0,0,0,0.15);
    }

    .provider-img {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        object-fit: cover;
        border: 3px solid #28a745;
    }

    .provider-info h5 {
        margin: 0;
        color: #333;
        font-weight: bold;
    }

    .package-title {
        font-size: 18px;
        color: #007bff;
        font-weight: 600;
    }

    .options-list {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 10px 15px;
    }

    .options-list li {
        margin-bottom: 5px;
    }

    .btn-offer {
        border-radius: 10px;
        padding: 8px 20px;
        font-weight: 600;
    }
</style>

<div class="container-fluid d-flex main-content">
    <?php echo $__env->make('dashboard.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="col dashboard-content p-4">

        <h3 class="mb-4">تقديم عرض سعر للبروفايدر</h3>

        <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="price-offer">

                
                <div class="d-flex align-items-center mb-3">
                    <img src="<?php echo e($booking->user?->prof_img_url ?? asset('images/default.png')); ?>"
                         alt="Provider"
                         class="provider-img me-3">

                    <div class="provider-info">
                        <h5><?php echo e($booking->provider?->f_name . ' ' . $booking->provider?->l_name); ?></h5>
                        <p class="text-muted mb-1"><?php echo e($booking->provider?->email); ?></p>
                        <p class="text-muted mb-0">المهنة: <?php echo e($booking->provider?->role ?? 'غير محدد'); ?></p>
                    </div>
                </div>

                
                

                
                <?php if($booking->options && count($booking->options)): ?>
                    <div class="options-list mb-3">
                        <strong>الخيارات المختارة:</strong>
                        <ul class="mb-0">
                            <?php $__currentLoopData = $booking->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>🔹 خيار رقم <?php echo e($option->package_option_id); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                
            <form action="<?php echo e(route('nursing_make_offer')); ?>" method="POST" class="mt-3">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">

    <div class="row g-3 align-items-center">

        

        
        <div class="col-md-4">
            <label class="form-label">السعر المقترح</label>
            <input type="number"
                   step="0.01"
                   name="provider_price"
                   class="form-control"
                   placeholder="اكتب السعر..."
                   value="<?php echo e($offer?->provider_price ?? ''); ?>">
        </div>

        
        <div class="col-md-3">
            <button class="btn btn-success btn-offer mt-4">
                <?php echo e($offer ? 'تعديل العرض' : 'إرسال العرض'); ?>

            </button>
        </div>
    </div>
</form>



            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="mt-3">
            <?php echo e($conversations->links()); ?>

        </div>

    </main>
</div>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/packages_nursing/make_nursing_price.blade.php ENDPATH**/ ?>