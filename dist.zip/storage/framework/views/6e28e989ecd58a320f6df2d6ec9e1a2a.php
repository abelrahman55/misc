    
<?php /**PATH /home/shaarapp/public_html/misc/resources/views/dashboard/layouts/header.blade.php ENDPATH**/ ?>