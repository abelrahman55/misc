<?php $__env->startSection('content'); ?>
    <style>
        /* 🌸 شبكة عرض الكروت */
        .grid-4 {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 1.5rem;
        }

        /* 🌿 تصميم الكارت */
        .patient-card {
            transition: all 0.3s ease;
            background-color: #fff;
            border: 1px solid #f1f1f1;
        }

        .patient-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
            border-color: #e0d8ff;
        }

        /* 🌸 الزر البنفسجي */
        .btn-purple {
            background-color: #6f42c1;
            border: none;
            transition: all 0.3s ease;
        }

        .btn-purple:hover {
            background-color: #5a32a3;
            box-shadow: 0 4px 10px rgba(111, 66, 193, 0.3);
        }

        /* 👤 صورة المستخدم */
        .patient-avatar {
            border: 3px solid #f8f9fa;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        }

        /* ✨ النصوص */
        .patient-name {
            font-weight: 600;
            font-size: 1.1rem;
        }

        .patient-info {
            font-size: 0.9rem;
            color: #6c757d;
        }

        /* 🔍 شريط البحث */
        .search-bar {
            max-width: 400px;
        }

        /* ⭐ تصميم النجوم */
        .star-rating {
            direction: rtl;
            display: inline-flex;
        }

        .star-rating input[type="radio"] {
            display: none;
        }

        .star-rating label {
            font-size: 1.8rem;
            color: #ddd;
            cursor: pointer;
            transition: color 0.2s;
        }

        .star-rating input[type="radio"]:checked~label {
            color: #ffc107;
        }

        .star-rating label:hover,
        .star-rating label:hover~label {
            color: #ffc107;
        }

        /* 📱 استجابة للشاشات الصغيرة */
        @media (max-width: 768px) {
            .grid-4 {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
                gap: 1rem;
            }
        }
    </style>

    <div class="container-fluid">
        <div class="row">
            
            <?php echo $__env->make('dashboard.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <main class="col-md-10 p-4" style="font-family: 'Noto Sans Lao', sans-serif;">
                <div class="row h-100">
                    <div class="col px-4 py-2 pb-0">
                        
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h2 class="text-1 text-dark mb-0">
                                <i class="bi bi-person-badge me-2 text-purple"></i> Doctors
                            </h2>

                            
                            <form method="GET" action="<?php echo e(route('patient_doctors')); ?>" class="search-bar">
                                <div class="input-group">
                                    <input type="text" name="search" class="form-control rounded-start-3"
                                        placeholder="Search by name or phone..." value="<?php echo e(request('search')); ?>">
                                    <button class="btn btn-purple text-white rounded-end-3">
                                        <i class="bi bi-search"></i>
                                    </button>
                                </div>
                            </form>
                        </div>

                        
                        <div class="grid-4 mb-4">
                            <?php $__empty_1 = true; $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="card patient-card text-center rounded-4 py-4 px-4">
                                    <div class="mx-auto mb-3">
                                        <img src="<?php echo e($doctor?->provider?->prof_img ? asset('storage/' . $doctor->provider->prof_img) : asset('default-avatar.png')); ?>"
                                            alt="User Avatar" class="rounded-circle patient-avatar" width="100"
                                            height="100">
                                    </div>

                                    <div class="patient-name mb-1">
                                        <?php echo e($doctor?->provider?->f_name); ?> <?php echo e($doctor?->provider?->l_name); ?>

                                    </div>

                                    <div class="patient-info"><?php echo e($doctor?->provider?->phone); ?></div>
                                    <div class="patient-info"><?php echo e($doctor?->provider?->address); ?></div>

                                    <?php if($doctor?->provider?->email): ?>
                                        <a href="mailto:<?php echo e($doctor->provider->email); ?>"
                                            class="text-decoration-none small text-primary d-block mt-1">
                                            <?php echo e($doctor->provider->email); ?>

                                        </a>
                                    <?php endif; ?>

                                    <hr class="my-3 d-flex justify-content-center">

                                    <div class="d-flex justify-content-center gap-2">
                                        <a href="<?php echo e(route('patient_profile', ['id' => $doctor?->provider?->id])); ?>"
                                            class="btn btn-purple text-white rounded-2 px-3 py-2">
                                            <i class="bi bi-list-check"></i> Details
                                        </a>

                                        
                                        <button type="button" class="btn btn-outline-warning rounded-2 px-3 py-2"
                                            data-bs-toggle="modal" data-bs-target="#rateDoctorModal"
                                            data-provider-id="<?php echo e($doctor?->provider?->id); ?>"
                                            data-provider-name="<?php echo e($doctor?->provider?->f_name); ?> <?php echo e($doctor?->provider?->l_name); ?>">
                                            <i class="bi bi-star"></i> Rate
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-center text-muted mt-4">No doctors found.</p>
                            <?php endif; ?>
                        </div>

                        
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($doctors->links('pagination::bootstrap-5')); ?>

                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    
    <div class="modal fade" id="rateDoctorModal" tabindex="-1" aria-labelledby="rateDoctorLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" action="<?php echo e(route('make_rate')); ?>" class="modal-content">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="rateDoctorLabel">Rate Doctor</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body text-center">
                    <input type="hidden" name="provider_id" id="provider_id" value="">
                    <p id="provider_name" class="fw-semibold text-purple"></p>

                    
                    <div class="star-rating mb-3">
                        <?php for($i = 5; $i >= 1; $i--): ?>
                            <input type="radio" name="rate" id="star<?php echo e($i); ?>" value="<?php echo e($i); ?>">
                            <label for="star<?php echo e($i); ?>">★</label>
                        <?php endfor; ?>
                    </div>

                    <div class="mb-3">
                        <textarea name="comment" class="form-control" placeholder="Write your comment..." rows="3"></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-purple text-white">Submit Rating</button>
                </div>
            </form>
        </div>
    </div>

    
    <script>
        const rateModal = document.getElementById('rateDoctorModal');
        rateModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const providerId = button.getAttribute('data-provider-id');
            const providerName = button.getAttribute('data-provider-name');

            document.getElementById('provider_id').value = providerId;
            document.getElementById('provider_name').textContent = providerName;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/patient_doctors.blade.php ENDPATH**/ ?>