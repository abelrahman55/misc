<?php echo $__env->make('dashboard.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid d-flex main-content">
    <?php echo $__env->make('dashboard.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="col dashboard-content p-4">

        <h2 class="mb-4">Welcome, <?php echo e(auth()->guard('web')->user()->f_name ?? 'Patient'); ?></h2>

        
        
        
        

        
        
        
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-success text-white">
                Hospital Bookings
            </div>
            <div class="card-body">

                <?php if($hospitalBookings->count()): ?>
                    <table class="table table-borderless table-hover text-center align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Package</th>
                                <th>Offer Price</th>
                                <th>Date</th>
                                <th>Created</th>
                                <th>Meetings</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $hospitalBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <?php echo e($booking->package->title['en'] ?? '-'); ?>

                                        <br>
                                        <small class="text-muted">
                                            <?php echo e(number_format($booking->package->price, 2)); ?> EGP
                                        </small>
                                    </td>
                                    <td>
                                        <?php if($booking->offer): ?>
                                            <?php echo e(number_format($booking->offer->provider_price, 2)); ?> EGP
                                        <?php else: ?>
                                            <span class="text-muted">No offer yet</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($booking->date); ?></td>
                                    <td><?php echo e($booking->created_at->format('Y-m-d')); ?></td>
                                    <td>
                                        <?php if($booking?->offer && $booking?->offer?->paid == 'success'): ?>
                                            <a class="btn btn-purple text-white btn-sm"
                                                href="<?php echo e(route('offer_meetings', ['id' => $booking->offer->id])); ?>">
                                                Meetings
                                            </a>
                                        <?php else: ?>
                                            <button class="btn btn-secondary btn-sm" disabled>
                                                No Offer
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($booking->offer && $booking->offer->paid != 'success'): ?>
                                            <button class="btn btn-purple text-white btn-sm" data-bs-toggle="modal"
                                                data-bs-target="#paymentModal" data-booking="<?php echo e($booking->id); ?>"
                                                data-price="<?php echo e($booking->offer->provider_price); ?>">
                                                💳 Pay
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-secondary btn-sm" disabled>
                                                No Offer
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-muted py-4">No bookings found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <?php echo e($hospitalBookings->links()); ?>

                <?php else: ?>
                    <p class="text-muted">No hospital bookings.</p>
                <?php endif; ?>

            </div>
        </div>


    </main>
</div>


<div class="modal fade" id="paymentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-purple text-white">
                <h5 class="modal-title">Complete Payment</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="paymentForm" action="<?php echo e(route('nursing_pay')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <input type="hidden" name="booking_id" id="bookingId">
                    <input type="hidden" name="price" id="bookingPrice">

                    <div class="mb-3">
                        <label class="form-label">Have a Coupon?</label>
                        <input type="text" name="coupon_code" class="form-control"
                            placeholder="Enter coupon code (optional)">
                    </div>

                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="use_points" id="usePoints">
                        <label class="form-check-label" for="usePoints">
                            Use my available points
                        </label>
                    </div>

                    <div class="alert alert-light border">
                        <strong>Total to pay:</strong> <span id="totalAmount" class="fw-bold">0</span> EGP
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-purple text-white">Confirm Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="paymentModal2" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-purple text-white">
                <h5 class="modal-title">Complete Payment</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="paymentForm" action="<?php echo e(route('package_pay')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <input type="hidden" name="booking_id" id="bookingId">
                    <input type="hidden" name="price" id="bookingPrice">

                    <div class="mb-3">
                        <label class="form-label">Have a Coupon?</label>
                        <input type="text" name="coupon_code" class="form-control"
                            placeholder="Enter coupon code (optional)">
                    </div>

                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="use_points" id="usePoints">
                        <label class="form-check-label" for="usePoints">
                            Use my available points
                        </label>
                    </div>

                    <div class="alert alert-light border">
                        <strong>Total to pay:</strong> <span id="totalAmount" class="fw-bold">0</span> EGP
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-purple text-white">Confirm Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
    <script>
        const modal = document.getElementById('paymentModal');
        modal.addEventListener('show.bs.modal', event => {
            const button = event.relatedTarget;
            const bookingId = button.getAttribute('data-booking');
            const price = button.getAttribute('data-price');
            document.getElementById('bookingId').value = bookingId;
            document.getElementById('bookingPrice').value = price;
            document.getElementById('totalAmount').innerText = price;
        });
    </script>
    <script>
        const modal = document.getElementById('paymentModal2');
        modal.addEventListener('show.bs.modal', event => {
            const button = event.relatedTarget;
            const bookingId = button.getAttribute('data-booking');
            const price = button.getAttribute('data-price');
            document.getElementById('bookingId').value = bookingId;
            document.getElementById('bookingPrice').value = price;
            document.getElementById('totalAmount').innerText = price;
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/provider_dash.blade.php ENDPATH**/ ?>