<?php echo $__env->make('dashboard.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php echo $__env->make('dashboard.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Main Content -->
        <main class="col dashboard-content p-4">
            <div class="d-flex gap-5">
                <div class="col">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h1 class="header-page">
                            <svg width="24" height="10" viewBox="0 0 24 10" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M7.61619 9.28003C7.40289 8.72536 7.1682 8.21336 6.9122 7.74403C6.65619 7.25336 6.36819 6.7947 6.04819 6.36803H23.2002V3.74403H6.04819C6.3469 3.31736 6.62419 2.86936 6.88019 2.40003C7.13619 1.90936 7.3709 1.3867 7.5842 0.832031H5.15219C3.82949 2.38936 2.37889 3.57336 0.800194 4.38403V5.76003C2.37889 6.52803 3.82949 7.70136 5.15219 9.28003H7.61619Z"
                                    fill="#141414" />
                            </svg>
                            Inquiry Details
                        </h1>
                        <a href="<?php echo e(route('inquiries.index')); ?>" class="btn btn-secondary">
                            <i class="bi bi-arrow-left"></i> Back
                        </a>
                    </div>

                    <div class="card p-4 mb-4">
                        <div class="card-body">
                            <h5 class="mb-3">Inquiry Information</h5>
                            <table class="table table-bordered">
                                <tr>
                                    <th>User</th>
                                    <td><?php echo e($inquiry->patient->f_name ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <th>Name</th>
                                    <td><?php echo e($inquiry->name ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Contact Details</th>
                                    <td><?php echo e($inquiry->contact_details ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Country</th>
                                    <td><?php echo e($inquiry->country->name[app()->getLocale()] ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Specialty</th>
                                    <td><?php echo e($inquiry->specialty->name[app()->getLocale()] ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Proximity</th>
                                    <td><?php echo e($inquiry->proximity ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Reputation</th>
                                    <td><?php echo e($inquiry->reputation ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Budget</th>
                                    <td><?php echo e(number_format($inquiry->budget, 2) ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Symptoms</th>
                                    <td><?php echo e($inquiry->symptoms ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Date</th>
                                    <td><?php echo e($inquiry->date ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Treatment Type</th>
                                    <td><?php echo e($inquiry->treatment_type ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Coordinator</th>
                                    <td><?php echo e($inquiry->assigned_coordintor ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        <span
                                            class="badge
                        <?php if($inquiry->status == 'pending'): ?> bg-warning
                        <?php elseif($inquiry->status == 'confirmed'): ?> bg-info
                        <?php elseif($inquiry->status == 'in_progress'): ?> bg-primary
                        <?php elseif($inquiry->status == 'awaiting_reply'): ?> bg-secondary
                        <?php elseif($inquiry->status == 'completed'): ?> bg-success <?php endif; ?>">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $inquiry->status))); ?>

                                        </span>
                                    </td>
                                </tr>
                            </table>

                            <h5 class="mt-4 mb-3">Attached Files</h5>
                            <?php if($inquiry->files->count()): ?>
                                <ul>
                                    <?php $__currentLoopData = $inquiry->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e($file->file); ?>" target="_blank">
                                                File <?php echo e($loop->iteration); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <p class="text-muted">No files attached.</p>
                            <?php endif; ?>
                        </div>
                    </div>


                    

                </div>
            </div>
        </main>
    </div>
</div>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/dashboard_patient/inquiries/show.blade.php ENDPATH**/ ?>