<?php echo $__env->make('dashboard.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php echo $__env->make('dashboard.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Main Content -->
        <main class="col-md-10 p-4 pb-0" style="font-family: Poppins, sans-serif;">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="header-page">All Coupons</h1>
                <a href="<?php echo e(route('create_coupon')); ?>" class="btn btn-purple text-white">
                    + Add New Coupon
                </a>
            </div>

            <!-- Alerts -->
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped align-middle text-center">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Code</th>
                                    <th>Discount (%)</th>
                                    <th>Min Order</th>
                                    <th>Usage Limit</th>
                                    <th>Used Count</th>
                                    <th>Status</th>
                                    <th>Start Date</th>
                                    <th>Expiry Date</th>
                                    <th>Created At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><strong><?php echo e($coupon->code); ?></strong></td>
                                        <td><?php echo e($coupon->discount_percent); ?>%</td>
                                        <td><?php echo e(number_format($coupon->min_order, 2)); ?></td>
                                        <td><?php echo e($coupon->usage_limit); ?></td>
                                        <td><?php echo e($coupon->used_count ?? 0); ?></td>
                                        <td>
                                            <?php if($coupon->status): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($coupon->starts_at?->format('Y-m-d H:i') ?? '-'); ?></td>
                                        <td><?php echo e($coupon->expires_at?->format('Y-m-d H:i') ?? '-'); ?></td>
                                        <td><?php echo e($coupon->created_at->format('Y-m-d')); ?></td>

                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                    Actions
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li>
                                                        <a class="dropdown-item" href="<?php echo e(route('edit_coupon', ['id'=>$coupon->id])); ?>">
                                                            ✏️ Edit
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <form action="<?php echo e(route('delete_coupon', ['id'=>$coupon->id])); ?>" method="POST"
                                                            onsubmit="return confirm('Are you sure you want to delete this coupon?');">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="dropdown-item text-danger">
                                                                🗑️ Delete
                                                            </button>
                                                        </form>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="11" class="text-muted py-4">No coupons found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-3">
                        <?php echo e($coupons->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/coupons/index.blade.php ENDPATH**/ ?>