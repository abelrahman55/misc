<?php echo $__env->make('dashboard.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="content_wrapper with-sidenav">
    <div class="">
        <div class="row mb-5">
            <div class="col-12 col-xl-12">
                <div style="background-color: transparent !important" class="card">
                    <div class="add d-flex justify-content-end p-2">
                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles-create')): ?>
                        <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary">
                            <i class="fas fa-add"></i> <?php echo e(__('إضافه')); ?>

                        </a>
                        <?php endif; ?>
                        
                    </div>
                    <div class="card-body">
                        <div class="table-responsive text-center">
                            <table id="example2" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('#')); ?></th>
                                        <th><?php echo e(__('الاسم')); ?></th>
                                        <th><?php echo e(__('عدد الصلاحيات')); ?></th>
                                        <th><?php echo e(__('عدد المستخدمين')); ?></th>
                                        <th><?php echo e(__('العمليات')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($role->id); ?></td>
                                        <td><?php echo e($role->name); ?></td>
                                        <td><?php echo e(count($role->permissions)); ?></td>
                                        <td><?php echo e(count($role->users)); ?></td>
                                        <td>
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles-delete')): ?>
                                            <button type="button" class="btn btn-danger w-25 delete-country-btn" data-id="<?php echo e($role->id); ?>">
                                                <i class="far fa-trash-alt"></i>
                                            </button>
                                            <?php endif; ?>
                                            
                                            
                                            <a href="<?php echo e(route('roles.edit', $role)); ?>" class="btn btn-info w-25">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(abilities: 'roles-update')): ?>
                                            <?php endif; ?>
                                            
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5"><?php echo e(__('No data available!')); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <div style="padding:5px;direction: ltr;">
                                <?php echo $roles->withQueryString()->links('pagination::bootstrap-5'); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>



  <?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll('.delete-country-btn').forEach(button => {
            button.addEventListener('click', function () {
                let id = this.getAttribute('data-id');
                console.log("Trying to delete role with ID:", id); // Debug

                Swal.fire({
                    title: '<?php echo e(__("هل انت متأكد")); ?>',
                    text: "<?php echo e(__('هل تريد مسح هذا')); ?>",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#DC143C',
                    cancelButtonColor: '#696969',
                    cancelButtonText: "<?php echo e(__('Cancel')); ?>",
                    confirmButtonText: '<?php echo e(__("نعم!")); ?>'
                }).then((result) => {
                    if (result.isConfirmed) {
                        let form = document.createElement('form');
                        form.action = '<?php echo e(url("/admin/roles")); ?>/' + id;
                        form.method = 'POST';
                        form.style.display = 'none';

                        let csrfInput = document.createElement('input');
                        csrfInput.type = 'hidden';
                        csrfInput.name = '_token';
                        csrfInput.value = '<?php echo e(csrf_token()); ?>';

                        let methodInput = document.createElement('input');
                        methodInput.type = 'hidden';
                        methodInput.name = '_method';
                        methodInput.value = 'DELETE';

                        form.appendChild(csrfInput);
                        form.appendChild(methodInput);
                        document.body.appendChild(form);
                        form.submit();
                    }
                });
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/roles/index.blade.php ENDPATH**/ ?>