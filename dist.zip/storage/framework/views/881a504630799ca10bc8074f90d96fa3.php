<?php echo $__env->make('dashboard.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid">
    <?php if(session('success')): ?>
        <div id="successMessage" class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div id="errorMessage" class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <div class="row">
        <?php echo $__env->make('dashboard.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main class="col-md-10 p-4 pb-0" style="font-family: Poppins, sans-serif;">
            <h1 class="header-page text-muted mb-4">blogs Management</h1>
            <div class="row">
                <div class="col pe-4">
                    <!-- Tabs -->
                    <nav class="mb-4 mx-1">
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <button class="nav-link active" id="nav-blogs-tab" data-bs-toggle="tab"
                                data-bs-target="#nav-blogs" type="button" role="tab" aria-controls="nav-blogs"
                                aria-selected="true">blogs</button>
                            <!--<button class="nav-link" id="nav-appoinments-tab" data-bs-toggle="tab"-->
                            <!--    data-bs-target="#nav-appoinments" type="button" role="tab"-->
                            <!--    aria-controls="nav-appoinments" aria-selected="false">Appointments</button>-->
                            <!--<button class="nav-link" id="nav-payments-tab" data-bs-toggle="tab"-->
                            <!--    data-bs-target="#nav-payments" type="button" role="tab"-->
                            <!--    aria-controls="nav-payments" aria-selected="false">Payments</button>-->
                        </div>
                    </nav>
                    <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-primary rounded-3 btn-sm">
                        Create
                    </a>
                    <!-- Tap Contents -->
                    <div class="card border-0 p-4 rounded-4">

                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-blogs" role="tabpanel"
                                aria-labelledby="nav-blogs-tab">
                                <table class="table table-borderless transaction-table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Title</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Image</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!--  -->

                                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <td><?php echo e($loop->index + 1); ?></td>
                                                <td class="text-muted"><?php echo e($blog->title[app()->getLocale()]); ?></td>
                                                <td class="text-muted"><?php echo e($blog->description[app()->getLocale()]); ?>

                                                </td>
                                                <td class="text-muted">
                                                    <img src="<?php echo e(asset('storage/app/public/' . $blog->image )); ?>" alt="Blog Image" width="50"
                                                        height="50" class="img-thumbnail">
                                                </td>

                                                <td class="text-muted">
                                                    <?php echo e($blog->status == '1' ? 'active' : 'inactive'); ?>

                                                </td>
                                                <td>
                                                    <div class="d-flex gap-2">
                                                        <a href="<?php echo e(route('blogs.edit', $blog->id)); ?>"
                                                            class="btn btn-primary rounded-3 btn-sm">
                                                            Update
                                                        </a>

                                                        <form action="<?php echo e(route('blogs.delete', ['id' => $blog->id])); ?>"
                                                            method="POST"
                                                            onsubmit="return confirm('Are you sure you want to delete this article?');">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit"
                                                                class="btn btn-danger rounded-3 btn-sm">Delete</button>
                                                        </form>
                                                    </div>
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                            <div class="tab-pane fade" id="nav-appoinments" role="tabpanel"
                                aria-labelledby="nav-appoinments-tab">
                                <table class="table table-borderless table-hover transaction-table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Time</th>
                                            <th scope="col">blogs</th>
                                            <th scope="col">Specialty</th>
                                            <th scope="col">Technician</th>
                                            <th scope="col">Location</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Actions</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>7:00 - 7:10</td>
                                            <td>Braha Marlam Roh</td>
                                            <td>Cardiology</td>
                                            <td>Valeria</td>
                                            <td>Hagana 16, Tel Aviv</td>
                                            <td>Visited</td>
                                            <td>
                                                <button type="button" class="btn bi bi-three-dots text-dark"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item" href="#">Reschedule</a></li>
                                                    <li><a class="dropdown-item" href="#">Approve</a></li>
                                                    <li><a class="dropdown-item" href="#">Cancel</a>
                                                </ul>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="tab-pane fade" id="nav-payments" role="tabpanel"
                                aria-labelledby="nav-payments-tab">
                                <table class="table table-borderless table-hover transaction-table">
                                    <thead>
                                        <tr>
                                            <th scope="col">blogs</th>
                                            <th scope="col">Provider</th>
                                            <th scope="col">Value</th>
                                            <th scope="col">Status</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Braha Marlam Roh</td>
                                            <td>Valeria</td>
                                            <td>1612$</td>
                                            <td>Visited</td>
                                        </tr>

                                    </tbody>
                                </table>

                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </main>
    </div>
</div>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/Blog/index.blade.php ENDPATH**/ ?>