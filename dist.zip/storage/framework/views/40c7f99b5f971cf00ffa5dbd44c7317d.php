            <aside class="col-md-2 d-flex flex-column justify-content-between p-2 bg-white">
                <ul class="nav-links flex-column nav position-relative ">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patient_welcome')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('patient_welcome')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                        class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Home
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_welcome')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin_welcome')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                        class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Home
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(auth()?->guard('web')?->user()?->type == 'hospital'): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('welcome_provider')): ?>
                            <li class="nav-item">
                                <a href=<?php echo e(route('welcome_provider')); ?> class="nav-link d-flex align-items-center gap-3">
                                    <div class="box-icon">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path d="M6.66667 2H2V6.66667H6.66667V2Z" fill="#347FC2" fill-opacity="0.98"
                                                stroke="#347FC2" stroke-opacity="0.98" stroke-width="1.59942"
                                                stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M14.0002 2H9.3335V6.66667H14.0002V2Z" stroke="#347FC2"
                                                stroke-opacity="0.98" stroke-width="1.59942" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path d="M14.0002 9.33398H9.3335V14.0007H14.0002V9.33398Z" fill="#347FC2"
                                                fill-opacity="0.98" stroke="#347FC2" stroke-opacity="0.98"
                                                stroke-width="1.59942" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M6.66667 9.33398H2V14.0007H6.66667V9.33398Z" stroke="#347FC2"
                                                stroke-opacity="0.98" stroke-width="1.59942" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    Dashboard
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if(auth()?->guard('web')?->user()?->type == 'doctor'): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('welcome_doctor')): ?>
                            <li class="nav-item">
                                <a href=<?php echo e(route('welcome_doctor')); ?> class="nav-link d-flex align-items-center gap-3">
                                    <div class="box-icon">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path d="M6.66667 2H2V6.66667H6.66667V2Z" fill="#347FC2" fill-opacity="0.98"
                                                stroke="#347FC2" stroke-opacity="0.98" stroke-width="1.59942"
                                                stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M14.0002 2H9.3335V6.66667H14.0002V2Z" stroke="#347FC2"
                                                stroke-opacity="0.98" stroke-width="1.59942" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path d="M14.0002 9.33398H9.3335V14.0007H14.0002V9.33398Z" fill="#347FC2"
                                                fill-opacity="0.98" stroke="#347FC2" stroke-opacity="0.98"
                                                stroke-width="1.59942" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M6.66667 9.33398H2V14.0007H6.66667V9.33398Z" stroke="#347FC2"
                                                stroke-opacity="0.98" stroke-width="1.59942" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    Dashboard
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if(auth()?->guard('web')?->user()?->type == 'hospital'): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('provider_reservations')): ?>
                            <li class="nav-item">
                                <a href=<?php echo e(route('provider_reservations')); ?>

                                    class="nav-link d-flex align-items-center gap-3">
                                    <div class="box-icon">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path d="M6.66667 2H2V6.66667H6.66667V2Z" fill="#347FC2" fill-opacity="0.98"
                                                stroke="#347FC2" stroke-opacity="0.98" stroke-width="1.59942"
                                                stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M14.0002 2H9.3335V6.66667H14.0002V2Z" stroke="#347FC2"
                                                stroke-opacity="0.98" stroke-width="1.59942" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path d="M14.0002 9.33398H9.3335V14.0007H14.0002V9.33398Z" fill="#347FC2"
                                                fill-opacity="0.98" stroke="#347FC2" stroke-opacity="0.98"
                                                stroke-width="1.59942" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M6.66667 9.33398H2V14.0007H6.66667V9.33398Z" stroke="#347FC2"
                                                stroke-opacity="0.98" stroke-width="1.59942" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    Reservations
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_patients')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin_patients')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Patients
                            </a>
                        </li>
                    <?php endif; ?>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('about_us')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('aboutus.create')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                AboutUs
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('articles')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('articles.index')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Articles
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('services')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('services.index')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Service
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('blogs')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('blogs.index')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Blogs
                            </a>
                        </li>
                    <?php endif; ?>
                    

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faqs')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('faqs.index')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Faqs
                            </a>
                        </li>
                    <?php endif; ?>



                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('provider_profile')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('provider_profile')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">

                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                                        <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
                                    </svg>
                                </div>
                                Profile
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if(auth()?->guard('web')?->user()?->type == 'doctor'): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctor_patients')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('provider_patient')); ?>"
                                    class="nav-link d-flex align-items-center gap-3">
                                    <div class="box-icon">

                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                            fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                                            <path
                                                d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
                                        </svg>
                                    </div>
                                    doctor Patients
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctor_reviews_ratings')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('provider_ratings')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">

                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                                        <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
                                    </svg>
                                </div>
                                Reviews & Ratings
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if(auth()?->guard('web')?->user()?->type == 'doctor'): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctor_reviews_ratings')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('provider_schedules')); ?>"
                                    class="nav-link d-flex align-items-center gap-3">
                                    <div class="box-icon">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_681_14049)">
                                                <path
                                                    d="M3.54669 15.0312H2.60919C2.42271 15.0312 2.24387 14.9572 2.11201 14.8253C1.98015 14.6934 1.90607 14.5146 1.90607 14.3281V10.1094C1.90607 9.92289 1.98015 9.74405 2.11201 9.61219C2.24387 9.48033 2.42271 9.40625 2.60919 9.40625H3.54669C3.73317 9.40625 3.91201 9.48033 4.04388 9.61219C4.17574 9.74405 4.24982 9.92289 4.24982 10.1094V14.3281C4.24982 14.5146 4.17574 14.6934 4.04388 14.8253C3.91201 14.9572 3.73317 15.0312 3.54669 15.0312V15.0312Z"
                                                    fill="#347FC2" fill-opacity="0.98" />
                                                <path
                                                    d="M10.1092 15.0312H9.17172C8.98524 15.0312 8.8064 14.9572 8.67454 14.8253C8.54268 14.6934 8.4686 14.5146 8.4686 14.3281V7.29687C8.4686 7.11039 8.54268 6.93155 8.67454 6.79969C8.8064 6.66783 8.98524 6.59375 9.17172 6.59375H10.1092C10.2957 6.59375 10.4745 6.66783 10.6064 6.79969C10.7383 6.93155 10.8123 7.11039 10.8123 7.29687V14.3281C10.8123 14.5146 10.7383 14.6934 10.6064 14.8253C10.4745 14.9572 10.2957 15.0312 10.1092 15.0312V15.0312Z"
                                                    fill="#347FC2" fill-opacity="0.98" />
                                                <path
                                                    d="M13.3904 15.0312H12.4529C12.2665 15.0312 12.0876 14.9572 11.9558 14.8253C11.8239 14.6934 11.7498 14.5146 11.7498 14.3281V4.01562C11.7498 3.82914 11.8239 3.6503 11.9558 3.51844C12.0876 3.38658 12.2665 3.3125 12.4529 3.3125H13.3904C13.5769 3.3125 13.7558 3.38658 13.8876 3.51844C14.0195 3.6503 14.0936 3.82914 14.0936 4.01562V14.3281C14.0936 14.5146 14.0195 14.6934 13.8876 14.8253C13.7558 14.9572 13.5769 15.0312 13.3904 15.0312V15.0312Z"
                                                    fill="#347FC2" fill-opacity="0.98" />
                                                <path
                                                    d="M6.82796 15.0312H5.89046C5.70398 15.0312 5.52513 14.9572 5.39327 14.8253C5.26141 14.6934 5.18733 14.5146 5.18733 14.3281V1.67187C5.18733 1.48539 5.26141 1.30655 5.39327 1.17469C5.52513 1.04283 5.70398 0.96875 5.89046 0.96875H6.82796C7.01444 0.96875 7.19328 1.04283 7.32514 1.17469C7.457 1.30655 7.53108 1.48539 7.53108 1.67187V14.3281C7.53108 14.5146 7.457 14.6934 7.32514 14.8253C7.19328 14.9572 7.01444 15.0312 6.82796 15.0312V15.0312Z"
                                                    fill="#347FC2" fill-opacity="0.98" />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_681_14049">
                                                    <rect width="15" height="15" fill="white"
                                                        transform="translate(0.499847 0.5)" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    Provider Scedule
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>



                    <!--<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inquiries')): ?>-->
                    <!--    <li class="nav-item">-->
                    <!--        <a href="<?php echo e(route('inquiries.index')); ?>" class="nav-link d-flex align-items-center gap-3">-->
                    <!--            <div class="box-icon">-->
                    <!--                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"-->
                    <!--                    fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">-->
                    <!--                    <path-->
                    <!--                        d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />-->
                    <!--                </svg>-->
                    <!--            </div>-->
                    <!--            Inquiries-->
                    <!--        </a>-->
                    <!--    </li>-->
                    <!--<?php endif; ?>-->

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('document_center')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('document_centers')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Documents Center
                            </a>
                        </li>
                    <?php endif; ?>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('package-options')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('package-options.index')); ?>"
                                class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Package Options
                            </a>
                        </li>
                    <?php endif; ?>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('packages')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('packages.index')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Packages
                            </a>
                        </li>
                    <?php endif; ?>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('packages_nursing')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('packages_nursing.index')); ?>"
                                class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Nursing Packages
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('package-options-nursing')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('package-options-nursing.index')); ?>"
                                class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Nursing Package Options
                            </a>
                        </li>
                    <?php endif; ?>




                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('package-options-hospital')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('package-options-hospital.index')); ?>"
                                class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Package Options Providers
                            </a>
                        </li>
                    <?php endif; ?>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('packages_hospital')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('packages_hospital.index')); ?>"
                                class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Packages Providers
                            </a>
                        </li>
                    <?php endif; ?>



                    

                    
                    


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupons')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('coupons')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                coupons
                                
                            </a>
                        </li>
                    <?php endif; ?>





                    

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('my_nursing_bookings')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('my_nursing_bookings')); ?>"
                                class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Care bookings
                                
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('my_provider_bookings')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('my_provider_bookings')); ?>"
                                class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Providers bookings
                                
                            </a>
                        </li>
                    <?php endif; ?>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('my_sick_bookings')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('my_sick_bookings')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Sick bookings
                                
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patient_doctors')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('patient_doctors')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Doctors
                                
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patient_provider')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('patient_provider')); ?>" class="nav-link d-flex align-items-center gap-3">
                                <div class="box-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
                                        <path
                                            d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    </svg>
                                </div>
                                Providers
                                
                            </a>
                        </li>
                    <?php endif; ?>


                    <li class="nav-item">
                        <a href="<?php echo e(route('log_out')); ?>" class="nav-link d-flex align-items-center gap-3">
                            <div class="box-icon">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_681_14049)">
                                        <path
                                            d="M3.54669 15.0312H2.60919C2.42271 15.0312 2.24387 14.9572 2.11201 14.8253C1.98015 14.6934 1.90607 14.5146 1.90607 14.3281V10.1094C1.90607 9.92289 1.98015 9.74405 2.11201 9.61219C2.24387 9.48033 2.42271 9.40625 2.60919 9.40625H3.54669C3.73317 9.40625 3.91201 9.48033 4.04388 9.61219C4.17574 9.74405 4.24982 9.92289 4.24982 10.1094V14.3281C4.24982 14.5146 4.17574 14.6934 4.04388 14.8253C3.91201 14.9572 3.73317 15.0312 3.54669 15.0312V15.0312Z"
                                            fill="#347FC2" fill-opacity="0.98" />
                                        <path
                                            d="M10.1092 15.0312H9.17172C8.98524 15.0312 8.8064 14.9572 8.67454 14.8253C8.54268 14.6934 8.4686 14.5146 8.4686 14.3281V7.29687C8.4686 7.11039 8.54268 6.93155 8.67454 6.79969C8.8064 6.66783 8.98524 6.59375 9.17172 6.59375H10.1092C10.2957 6.59375 10.4745 6.66783 10.6064 6.79969C10.7383 6.93155 10.8123 7.11039 10.8123 7.29687V14.3281C10.8123 14.5146 10.7383 14.6934 10.6064 14.8253C10.4745 14.9572 10.2957 15.0312 10.1092 15.0312V15.0312Z"
                                            fill="#347FC2" fill-opacity="0.98" />
                                        <path
                                            d="M13.3904 15.0312H12.4529C12.2665 15.0312 12.0876 14.9572 11.9558 14.8253C11.8239 14.6934 11.7498 14.5146 11.7498 14.3281V4.01562C11.7498 3.82914 11.8239 3.6503 11.9558 3.51844C12.0876 3.38658 12.2665 3.3125 12.4529 3.3125H13.3904C13.5769 3.3125 13.7558 3.38658 13.8876 3.51844C14.0195 3.6503 14.0936 3.82914 14.0936 4.01562V14.3281C14.0936 14.5146 14.0195 14.6934 13.8876 14.8253C13.7558 14.9572 13.5769 15.0312 13.3904 15.0312V15.0312Z"
                                            fill="#347FC2" fill-opacity="0.98" />
                                        <path
                                            d="M6.82796 15.0312H5.89046C5.70398 15.0312 5.52513 14.9572 5.39327 14.8253C5.26141 14.6934 5.18733 14.5146 5.18733 14.3281V1.67187C5.18733 1.48539 5.26141 1.30655 5.39327 1.17469C5.52513 1.04283 5.70398 0.96875 5.89046 0.96875H6.82796C7.01444 0.96875 7.19328 1.04283 7.32514 1.17469C7.457 1.30655 7.53108 1.48539 7.53108 1.67187V14.3281C7.53108 14.5146 7.457 14.6934 7.32514 14.8253C7.19328 14.9572 7.01444 15.0312 6.82796 15.0312V15.0312Z"
                                            fill="#347FC2" fill-opacity="0.98" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_681_14049">
                                            <rect width="15" height="15" fill="white"
                                                transform="translate(0.499847 0.5)" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </div>
                            Logout
                        </a>
                    </li>

                </ul>
                <!-- Doc -->
                



            </aside>
<?php /**PATH /home/shaarapp/public_html/misc/resources/views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>