<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div
        class="msg-wrapper <?php echo e($message?->user_id == auth()->id() || auth()->guard('web')->user()->role == 'admin' ? 'sent-box' : 'received-box'); ?>">
        <div
            class="msg <?php echo e($message?->user_id == auth()->id() || auth()->guard('web')->user()->role == 'admin' ? 'sent' : 'received'); ?>">
            <div class="sender-name"><?php echo e($message?->user?->name); ?></div>

            
            <?php if($message->message): ?>
                <div><?php echo e($message->message); ?></div>
            <?php endif; ?>

            
            <?php if($message->file): ?>
                <?php
                    $extension = strtolower(pathinfo($message->file, PATHINFO_EXTENSION));
                    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                ?>

                <?php if(in_array($extension, $imageExtensions)): ?>
                    <div style="margin-top:5px;">
                        <img src="<?php echo e(asset('storage/' . $message->file)); ?>" alt="image"
                            style="max-width:200px; border-radius:10px;">
                    </div>
                <?php else: ?>
                    <div style="margin-top:5px;">
                        <a href="<?php echo e(asset('storage/' . $message->file)); ?>" target="_blank">
                            تحميل الملف
                        </a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="time"><?php echo e($message?->created_at?->format('H:i')); ?></div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/shaarapp/public_html/misc/resources/views/packages_nursing/_message_items.blade.php ENDPATH**/ ?>