<?php echo $__env->make('dashboard.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php echo $__env->make('dashboard_patient.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="col dashboard-content p-4">
            <div class="d-flex gap-5">
                <div class="col">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h1 class="header-page">Edit Inquiry #<?php echo e($inquiry->id); ?></h1>
                        <a href="<?php echo e(route('inquiries.index')); ?>" class="btn btn-secondary">← Back</a>
                    </div>

                    <form action="<?php echo e(route('inquiries.update', $inquiry->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row d-flex justify-content-between mb-5">
                            <!-- General Info -->
                            <div class="col d-flex flex-column w-100">
                                <div class="rounded bg-white p-3 mb-5">
                                    <p>General Info</p>
                                </div>
                                <div class="rounded bg-white p-3 h-100">
                                    <div class="mb-3">
                                        <label class="form-label">Date</label>
                                        <input type="date" name="date" class="form-control"
                                            value="<?php echo e(old('date', $inquiry->date)); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Treatment Type</label>
                                        <input type="text" name="treatment_type" class="form-control"
                                            value="<?php echo e(old('treatment_type', $inquiry->treatment_type)); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Assigned Coordinator</label>
                                        <input type="text" name="assigned_coordintor" class="form-control"
                                            value="<?php echo e(old('assigned_coordintor', $inquiry->assigned_coordintor)); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Name</label>
                                        <input type="text" name="name" class="form-control"
                                            value="<?php echo e(old('name', $inquiry->name)); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Contact Details</label>
                                        <input type="text" name="contact_details" class="form-control"
                                            value="<?php echo e(old('contact_details', $inquiry->contact_details)); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Country</label>
                                        <select name="country_id" class="form-control">
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->id); ?>"
                                                    <?php echo e($inquiry->country_id == $country->id ? 'selected' : ''); ?>>
                                                    <?php echo e($country->getTranslation('name', app()->getLocale())); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Specialty</label>
                                        <select name="specialty_id" class="form-control">
                                            <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($specialty->id); ?>"
                                                    <?php echo e($inquiry->specialty_id == $specialty->id ? 'selected' : ''); ?>>
                                                    <?php echo e($specialty->title[app()->getLocale()]); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Proximity</label>
                                        <input type="text" name="proximity" class="form-control"
                                            value="<?php echo e(old('proximity', $inquiry->proximity)); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Reputation</label>
                                        <input type="text" name="reputation" class="form-control"
                                            value="<?php echo e(old('reputation', $inquiry->reputation)); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Budget</label>
                                        <input type="number" step="0.01" name="budget" class="form-control"
                                            value="<?php echo e(old('budget', $inquiry->budget)); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Symptoms</label>
                                        <textarea name="symptoms" class="form-control"><?php echo e(old('symptoms', $inquiry->symptoms)); ?></textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Status</label>
                                        <select name="status" class="form-control">
                                            <option value="pending"
                                                <?php echo e($inquiry->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                            <option value="confirmed"
                                                <?php echo e($inquiry->status == 'confirmed' ? 'selected' : ''); ?>>Confirmed
                                            </option>
                                            <option value="in_progress"
                                                <?php echo e($inquiry->status == 'in_progress' ? 'selected' : ''); ?>>In Progress
                                            </option>
                                            <option value="awaiting_reply"
                                                <?php echo e($inquiry->status == 'awaiting_reply' ? 'selected' : ''); ?>>Awaiting
                                                Reply</option>
                                            <option value="completed"
                                                <?php echo e($inquiry->status == 'completed' ? 'selected' : ''); ?>>Completed
                                            </option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Attachments -->
                            <div class="col d-flex flex-column w-100">
                                <div class="rounded bg-white p-3 mb-5">
                                    <p>Attached Documents</p>
                                </div>
                                <div class="d-flex flex-column gap-3 rounded bg-white p-3 h-100">
                                    <input type="file" name="files[]" class="form-control mb-3" multiple>

                                    <?php if($inquiry->files->count()): ?>
                                        <?php $__currentLoopData = $inquiry->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div
                                                class="d-flex justify-content-between align-items-start border p-2 rounded">
                                                <div class="d-flex gap-3 align-items-start">
                                                    <div>
                                                        <i class="bi bi-file-earmark-text"></i>
                                                    </div>
                                                    <div class="d-flex flex-column">
                                                        <span class="file-name"><?php echo e(basename($file->file)); ?></span>
                                                        <a href="<?php echo e(asset('storage/app/public/' . $file->file)); ?>" target="_blank">
    Click to view
</a>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <span class="text-muted">No files uploaded</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">Update Inquiry</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/dashboard_patient/inquiries/edit.blade.php ENDPATH**/ ?>