<?php echo $__env->make('dashboard.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid d-flex main-content">
    <?php echo $__env->make('dashboard.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="col dashboard-content p-4">

        <div class="row mb-3">
            <div class="col d-flex justify-content-between align-items-center">
                <h1 class="header-page">Meetings</h1>

            </div>
        </div>

        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <div class="card shadow-sm">
            <div class="card-body">
                <h4 class="mb-3">Meetings List</h4>
                <table class="table table-striped align-middle">
                    <thead class="table-primary">
                        <tr>
                            <th>#</th>
                            <th>User</th>
                            <th>Doctor</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Link</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($appointment->user?->f_name ?? '—'); ?></td>
                                <td><?php echo e($appointment->doctor?->f_name ?? '—'); ?></td>
                                <td><?php echo e($appointment->date ?? '—'); ?></td>
                                <td><?php echo e($appointment->time ?? '—'); ?></td>
                                <td>
                                    <?php if($appointment->meeting && $appointment->ended == 0): ?>
                                        <?php if($appointment->meeting && $appointment->ended == 0): ?>
                                            <a target="_blank" class="btn btn-sm btn-success">
                                                <i class="bi bi-camera-video"></i> Join
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">No link</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">No link</span>
                                    <?php endif; ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">No meetings found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/client_meetings.blade.php ENDPATH**/ ?>