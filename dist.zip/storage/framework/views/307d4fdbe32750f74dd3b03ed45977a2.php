<?php echo $__env->make('dashboard.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php echo $__env->make('dashboard.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Main Content -->
        <main class="col-md-10 p-4 pb-0" style="font-family: Poppins, sans-serif;">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="header-page">All Packages Hospital</h1>
                <a href="<?php echo e(route('packages_hospital.create')); ?>" class="btn btn-purple text-white">
                    + Add New Package Hospital
                </a>
            </div>

            <!-- Alerts -->
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped align-middle text-center">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Title (EN)</th>
                                    <th>Title (AR)</th>
                                    <th>Price</th>
                                    <th>Options Count</th>
                                    <th>Created At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($package->title['en'] ?? '-'); ?></td>
                                        <td><?php echo e($package->title['ar'] ?? '-'); ?></td>
                                        <td><?php echo e(number_format($package->price, 2)); ?> EGP</td>
                                        <td>
                                            <span class="badge bg-purple text-white">
                                                <?php echo e($package->optionsHospital->count()); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($package?->created_at?->format('Y-m-d')??""); ?></td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                    Actions
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li>
                                                        <a class="dropdown-item" href="<?php echo e(route('packages_hospital.show', $package->id)); ?>">
                                                            👁️ View
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item" href="<?php echo e(route('packages_providers_reservations', ['id'=>$package->id])); ?>">
                                                            Reservations
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item" href="<?php echo e(route('packages_hospital.edit', $package->id)); ?>">
                                                            ✏️ Edit
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <form action="<?php echo e(route('packages_hospital.destroy', $package->id)); ?>" method="POST"
                                                            onsubmit="return confirm('Are you sure you want to delete this package?');">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="dropdown-item text-danger">
                                                                🗑️ Delete
                                                            </button>
                                                        </form>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-muted py-4">No packages found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-3">
                        <?php echo e($packages->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/packages_hospital/index.blade.php ENDPATH**/ ?>