<?php echo $__env->make('dashboard.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('dashboard.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main class="col-md-10 px-4 py-0">
            <div class="row h-100">

                <div class="col-4 px-0 bg-white shadow-sm">
                    <div class="p-4">
                        <h2 class="header-page-1 mb-5">
                            <i class="bi bi-arrow-left-short"></i>
                            Patient Profile
                        </h2>

                        <div class="d-flex flex-column gap-1 align-items-center mb-3">
                            <img src="<?php echo e(asset('storage/' . $patient->prof_img)); ?>" alt="patient" width="65"
                                height="65" class="rounded-circle img-thumbnail">
                            <span class="heading-3 fw-bold text-dark"><?php echo e($patient->f_name ?? ''); ?> Hi</span>
                            <div class="d-flex gap-1 text-3 text-head">
                                <span><?php echo e($patient->age); ?> years old</span>
                                <span>|</span>
                                <span><i class="bi bi-geo-alt"></i>
                                    <?php echo e(isset($patient->country) ? $patient->country->getTranslation('name', app()->getLocale()) : ''); ?></span>
                            </div>
                        </div>
                    </div>


                    <div class="d-flex align-items-start">
                        <div class="nav flex-column nav-pills nav-profile w-100 px-1" id="v-pills-tab" role="tablist"
                            aria-orientation="vertical">
                            <button class="nav-link active text-start" id="v-pills-info-tab" data-bs-toggle="pill"
                                data-bs-target="#v-pills-info" type="button" role="tab"
                                aria-controls="v-pills-info" aria-selected="true">General Information</button>

                            

                            <button class="nav-link text-start" id="v-pills-notes-tab" data-bs-toggle="pill"
                                data-bs-target="#v-pills-notes" type="button" role="tab"
                                aria-controls="v-pills-notes" aria-selected="false">Consultation Notes</button>

                            <button class="nav-link text-start" id="v-pills-files-tab" data-bs-toggle="pill"
                                data-bs-target="#v-pills-files" type="button" role="tab"
                                aria-controls="v-pills-files" aria-selected="false">Files</button>
                        </div>
                    </div>
                </div>


                <div class="col p-4 h-100">
                    <div class="tab-content" id="v-pills-tabContent">


                        <div class="tab-pane fade show active" id="v-pills-info" role="tabpanel"
                            aria-labelledby="v-pills-info-tab">

                            <div class="d-flex flex-column gap-3 overflow-auto" style="max-height: 85vh;">

                                <?php if(session('success')): ?>
                                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                <?php endif; ?>

                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul class="mb-0">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <form action="<?php echo e(route('update_profile')); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($patient->id); ?>"
                                        <?php echo e(auth()->guard('web')->user()?->role == $patient?->role ? '' : 'disabled'); ?>>


                                    <div class="shadow-sm bg-white px-5 py-4 rounded mb-4">
                                        <h3 class="header-page mb-4">Demographics</h3>
                                        <div class="d-flex flex-column gap-3">
                                            <div class="row">
                                                <label class="col text-2 fw-bold" for="f_name">First Name</label>
                                                <input type="text" name="f_name" id="f_name"
                                                    class="form-control col"
                                                    value="<?php echo e(old('f_name', $patient->f_name)); ?>" required
                                                    <?php echo e(auth()->guard('web')->user()?->role == $patient?->role ? '' : 'disabled'); ?>>
                                            </div>
                                            <div class="row">
                                                <label class="col text-2 fw-bold" for="l_name">Last Name</label>
                                                <input type="text" name="l_name" id="l_name"
                                                    class="form-control col"
                                                    value="<?php echo e(old('l_name', $patient->l_name)); ?>"
                                                    <?php echo e(auth()->guard('web')->user()?->role == $patient?->role ? '' : 'disabled'); ?>>
                                            </div>
                                            <div class="row">
                                                <label class="col text-2 fw-bold" for="gender">Gender</label>
                                                <select
                                                    <?php echo e(auth()->guard('web')->user()?->role == $patient?->role ? '' : 'disabled'); ?>

                                                    name="gender" id="gender" class="form-select col">
                                                    <option value="male"
                                                        <?php echo e(old('gender', $patient->gender) == 'male' ? 'selected' : ''); ?>>
                                                        Male</option>
                                                    <option value="female"
                                                        <?php echo e(old('gender', $patient->gender) == 'female' ? 'selected' : ''); ?>>
                                                        Female</option>
                                                </select>
                                            </div>
                                            <div class="row">
                                                <label class="col text-2 fw-bold" for="dob">Date Of Birth</label>
                                                <input type="date" name="dob" id="dob"
                                                    class="form-control col" value="<?php echo e(old('dob', $patient->dob)); ?>"
                                                    <?php echo e(auth()->guard('web')->user()?->role == $patient?->role ? '' : 'disabled'); ?>>
                                            </div>
                                            <div class="row">
                                                <label class="col text-2 fw-bold">Age</label>
                                                <span class="col text-2 text-dark"><?php echo e($patient->age ?? ''); ?></span>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="shadow-sm bg-white px-5 py-4 rounded mb-4">
                                        <h3 class="header-page mb-4">Contact Information</h3>
                                        <div class="d-flex flex-column gap-3">
                                            <div class="row">
                                                <label class="col text-2 fw-bold" for="email">Email</label>
                                                <input type="email" name="email" id="email"
                                                    class="form-control col"
                                                    value="<?php echo e(old('email', $patient->email)); ?>" required
                                                    <?php echo e(auth()->guard('web')->user()?->role == $patient?->role ? '' : 'disabled'); ?>>

                                            </div>
                                            <div class="row">
                                                <label class="col text-2 fw-bold" for="phone">Phone</label>
                                                <input type="text" name="phone" id="phone"
                                                    class="form-control col"
                                                    value="<?php echo e(old('phone', $patient->phone)); ?>"
                                                    <?php echo e(auth()->guard('web')->user()?->role == $patient?->role ? '' : 'disabled'); ?>>
                                            </div>
                                            <div class="row">
                                                <label class="col text-2 fw-bold" for="address">Address</label>
                                                <input type="text" name="address" id="address"
                                                    class="form-control col"
                                                    value="<?php echo e(old('address', $patient->address)); ?>"
                                                    <?php echo e(auth()->guard('web')->user()?->role == $patient?->role ? '' : 'disabled'); ?>>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="shadow-sm bg-white px-5 py-4 rounded mb-4">
                                        <h3 class="header-page mb-4">Insurance</h3>
                                        <div class="d-flex flex-column gap-3">
                                            <div class="row">
                                                <label class="col text-2 fw-bold">Member Id</label>
                                                <span class="col text-2 text-dark"><?php echo e($patient->id); ?></span>
                                            </div>
                                            <div class="row">
                                                <label class="col text-2 fw-bold">Policy Holder</label>
                                                <span class="col text-2 text-dark"><?php echo e($patient->f_name); ?>

                                                    <?php echo e($patient->l_name); ?></span>
                                            </div>
                                        </div>
                                    </div>

                                    <?php if(auth()?->guard('web')?->user()?->role == 'patinet'): ?>
                                        <div class="shadow-sm bg-white px-5 py-4 rounded mb-4">
                                            <h3 class="header-page mb-4">Update Profile Image</h3>
                                            <input type="file" name="prof_img" accept="image/*"
                                                class="form-control">
                                        </div>


                                        <div class="shadow-sm bg-white px-5 py-4 rounded mb-4">
                                            <h3 class="header-page mb-4">Upload Additional File</h3>
                                            <input type="file" name="file"
                                                accept=".jpg,.jpeg,.png,.pdf,.doc,.docx" class="form-control">
                                        </div>
                                    <?php endif; ?>

                                    <?php if($patient->id == auth()->guard('web')->user()->id): ?>
                                    <button type="submit" class="btn btn-primary">Save Updates</button>
                                    <?php endif; ?>
                                </form>

                            </div>
                        </div>


                        <div class="tab-pane fade" id="v-pills-history" role="tabpanel"
                            aria-labelledby="v-pills-history-tab">
                            <div class="shadow-sm bg-white p-4 rounded">
                                <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
                                    <button class="nav-link active" id="nav-summary-tab" data-bs-toggle="tab"
                                        data-bs-target="#nav-summary" type="button" role="tab"
                                        aria-controls="nav-summary" aria-selected="true">Summary</button>
                                    <button class="nav-link" id="nav-conditions-tab" data-bs-toggle="tab"
                                        data-bs-target="#nav-conditions" type="button" role="tab"
                                        aria-controls="nav-conditions" aria-selected="false">Conditions</button>
                                    <button class="nav-link" id="nav-notes-tab" data-bs-toggle="tab"
                                        data-bs-target="#nav-notes" type="button" role="tab"
                                        aria-controls="nav-notes" aria-selected="false">Notes</button>
                                </div>

                                <div class="tab-content p-2" id="nav-tabContent">
                                    <div class="tab-pane fade show active" id="nav-summary" role="tabpanel"
                                        aria-labelledby="nav-summary-tab">
                                        James is a 32-year-old male with no known allergies or drug
                                        sensitivities. He has a history of seasonal allergies and occasional
                                        migraines. He takes no medications regularly.
                                    </div>
                                    <div class="tab-pane fade" id="nav-conditions" role="tabpanel"
                                        aria-labelledby="nav-conditions-tab">
                                        James is a 32-year-old male with no known allergies or drug
                                        sensitivities. He has a history of seasonal allergies and occasional
                                        migraines. He takes no medications regularly.
                                    </div>
                                    <div class="tab-pane fade" id="nav-notes" role="tabpanel"
                                        aria-labelledby="nav-notes-tab">
                                        James is a 32-year-old male with no known allergies or drug
                                        sensitivities. He has a history of seasonal allergies and occasional
                                        migraines. He takes no medications regularly.
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="tab-pane fade" id="v-pills-notes" role="tabpanel"
                            aria-labelledby="v-pills-notes-tab">
                            <div class="shadow-sm bg-white p-4 rounded">
                                <div class="d-flex flex-column gap-5 p-4">
                                    <?php $__currentLoopData = $patient->usernotes ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
                                            <div class="col-1">
                                                <div class="box-icon-purple">📝</div>
                                            </div>
                                            <div class="col d-flex flex-column gap-1">
                                                <span class="text-4"><?php echo e($note->created_at); ?></span>
                                                <span class="text-2"><?php echo e($note->note ?? ''); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>


                        <div class="tab-pane fade" id="v-pills-files" role="tabpanel"
                            aria-labelledby="v-pills-files-tab">
                            <div class="shadow-sm bg-white p-4 rounded">
                                <div class="d-flex flex-wrap gap-3 mb-3">
                                    <?php $__empty_1 = true; $__currentLoopData = $patient->files ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <a href="<?php echo e(asset('storage/' . $file->file)); ?>" target="_blank"
                                            class="d-block">
                                            <?php if(\Illuminate\Support\Str::endsWith($file->file, ['.jpg', '.jpeg', '.png'])): ?>
                                                <img src="<?php echo e(asset('storage/' . $file->file)); ?>" width="60"
                                                    height="60" class="img-thumbnail" />
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('assets/file.png')); ?>" width="60"
                                                    height="60" alt="file icon" />
                                            <?php endif; ?>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <p>No files uploaded yet.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/Patients/profile.blade.php ENDPATH**/ ?>