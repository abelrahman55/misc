<?php echo $__env->make('dashboard.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<style>
    .message-header {
        display: flex;
        gap: 16px;
        align-content: center;
        align-items: center;
    }

    .message-header .avatar {
        width: 35px;
        height: 35px;
        border-radius: 8px;
    }

    .message-body {
        padding-left: 50px;
    }

    .message-body p {
        color: rgba(99, 99, 99, 1);
    }

    .time {
        color: rgba(159, 167, 190, 1);
    }
</style>

<div class="container-fluid d-flex main-content">
    <?php echo $__env->make('dashboard.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="col dashboard-content p-4">
        <div class="row">
            <div class="col">
                <h1 class="header-page">All Messages</h1>
            </div>
        </div>

        <div class="row gap-3">
            <div class="col p-4">

                <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        // نجيب أول رسالة بأمان
                        $firstMessage = $conversation->messages_by_last->first();
                    ?>
                    
                    <a href="<?php echo e(route('provider_conv_messages',['id'=>$conversation->id])); ?>" class="message-container <?php echo e($firstMessage?->user_id == auth()->id() ? 'sent' : 'received'); ?>">
                        <div class="message-header">
                            <img src="<?php echo e($conversation->sender->profile_photo_url ?? asset('works/1752560823.jpg')); ?>"
                                alt="Sender" class="avatar" width="40" height="40">
                            <span><?php echo e($conversation->user->f_name ?? 'Unknown'); ?></span>
                        </div>

                        <div class="message-body">
                            <p><?php echo e($firstMessage?->message ?? 'No messages yet.'); ?></p>

                            
                            <?php if(!empty($firstMessage?->file) &&
                                (str_contains($firstMessage->file, '.jpg') ||
                                    str_contains($firstMessage->file, '.png') ||
                                    str_contains($firstMessage->file, '.jpeg'))): ?>
                                <img src="<?php echo e(asset('storage/' . $firstMessage->file)); ?>" alt="Attached Image"
                                    class="message-image" style="max-width: 200px; max-height: 200px;">
                            <?php endif; ?>

                            
                            <?php if(!empty($firstMessage?->voice)): ?>
                                <audio controls>
                                    <source src="<?php echo e(asset('storage/' . $firstMessage->voice)); ?>" type="audio/mpeg">
                                    Your browser does not support the audio element.
                                </audio>
                            <?php endif; ?>

                            
                            <?php if(!empty($firstMessage?->file) &&
                                !str_contains($firstMessage->file, '.jpg') &&
                                !str_contains($firstMessage->file, '.png') &&
                                !str_contains($firstMessage->file, '.jpeg')): ?>
                                <a href="<?php echo e(asset('storage/' . $firstMessage->file)); ?>" target="_blank">Download
                                    File</a>
                            <?php endif; ?>

                            
                            
                        </div>
                    </a>
                    <div style="display: flex;align-items: center;justify-content: end" class="make-price">
                        <a class="btn btn-primary my-2" href="<?php echo e(route('make_provider_price',['id'=>$conversation->id])); ?>">
                        عمل عرض سعر له
                    </a>
                    </div>

                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </main>
</div>

<?php $__env->startPush('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .message-container {
            margin-bottom: 15px;
            display: block;
            color: black;
            text-decoration: none;
        }

        .message-container.sent * {
            text-decoration: none;
            color: black;
        }

        .sent .message-body {
            background-color: #007bff;
            color: white;
            border-radius: 10px;
            padding: 10px;
            display: inline-block;
            margin-left: 20%;
            text-align: right;
        }

        .received .message-body {
            background-color: #e9ecef;
            border-radius: 10px;
            padding: 10px;
            display: inline-block;
            margin-right: 20%;
        }

        .message-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 5px;
        }

        .avatar {
            border-radius: 50%;
        }

        .time {
            font-size: 0.8em;
            color: #6c757d;
        }

        .message-image {
            margin-top: 10px;
            border-radius: 5px;
        }
        .make-price{
            display: flex;
            align-items: center;
            justify-content: start;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/shaarapp/public_html/misc/resources/views/packages_hospital/reservations.blade.php ENDPATH**/ ?>