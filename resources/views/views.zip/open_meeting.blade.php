<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Opening Meeting...</title>
</head>

<body>

    <script>
        // افتح جيسي في تاب جديد
        window.open("{{ $url }}", "_blank");

        // رجّع المستخدم للشاشة الأصلية بعد الفتح
    </script>

    <h3 style="padding:20px;">Opening meeting...</h3>

</body>

</html>
